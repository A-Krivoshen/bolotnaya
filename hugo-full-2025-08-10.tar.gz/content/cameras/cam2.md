---
name: Камера 2
stream_url: 'https://cam.fortesting.ru/boloto_new/index.m3u8'
image: /images/cam2.jpg
description: Второй ракурс
---

