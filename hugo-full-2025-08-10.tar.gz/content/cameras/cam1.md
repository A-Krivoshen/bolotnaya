---
name: Камера 1
stream_url: 'https://cam.fortesting.ru/lmost_new/index.m3u8'
image: /images/cam1.jpg
description: Основной вид
---

