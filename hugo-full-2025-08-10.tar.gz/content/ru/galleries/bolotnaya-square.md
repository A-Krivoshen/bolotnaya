---
slug: bolotnaya-square
title: Болотная площадь
description: Болотная площадь в Москве
images:
  - src: /images/galleries/IMG_0133.JPG
    caption: Памятник Репину
  - src: /images/galleries/history/9Q_C_Aqel-c.jpg
    caption: '2'
---

