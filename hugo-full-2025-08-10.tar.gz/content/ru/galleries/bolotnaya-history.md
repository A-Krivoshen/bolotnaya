---
slug: bolotnaya-history
title: История Болотной Площади
description: Фото История Болотной Площади
images:
  - src: /images/galleries/history/2023-03-31 10-29-27.JPG
    caption: болотная
  - src: >-
      /images/galleries/history/ENZA5rkQqmlGVulk2gX9KBzFrFUbBuTyEbXsjL8gZdtYJBPxuSAjPbP4mKLvMz80BXp_uRzDnsvgHmroF75_kNw6u6kkZB1N7KUuO669hf8S-u1e379to8T_P6H8JGmNSP2LPtQi2jCcqOjPqplKimFa6p7DXNh1UeSeQKXYkFx1kNVtA1-k4ELaK0iTd5QcI61KOKaU36VS3Tls2RDLIQ.jpeg
    caption: '='
---

