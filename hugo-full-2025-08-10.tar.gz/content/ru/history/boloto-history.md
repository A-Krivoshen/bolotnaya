---
slug: boloto-history
title: История Болотная площадь
description: Фото История Болотная площадь
gallery_slug: bolotnaya-history
---

