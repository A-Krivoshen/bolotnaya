---
title: "ул.Серафимовича"
date: 2025-05-12
description: "Онлайн-трансляция ул.Серафимовича"
id: "camera2"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
