---
title: "Болотная площадь"
date: 2025-05-12
description: "Онлайн-трансляция Болотной площади"
id: "camera1"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
