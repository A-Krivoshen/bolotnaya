---
title: "Онлайн-камеры"
date: 2025-05-12
description: "Прямые трансляции Якиманки"
id: "camera1"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
{{ partial "camera.html" . }}