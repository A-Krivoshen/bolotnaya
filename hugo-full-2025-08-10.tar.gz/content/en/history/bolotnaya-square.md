---
slug: bolotnaya-square
title: Болотная площадь
description: Bolotnaya square in Moscow
gallery_slug: bolotnaya-square
---

