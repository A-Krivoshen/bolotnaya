---
title: "Serafimovicha street"
date: 2025-05-12
description: "Live stream of Serafimovicha street"
id: "camera2"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
