---
title: "Bolotnaya Square"
date: 2025-05-12
description: "Bolotnaya Square View Bolotnaya Square in real-time"
id: "camera1"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
{{ partial "camera.html" . }}