---
title: "Bolotnaya Square"
date: 2025-05-12
description: "Live stream of Bolotnaya Square"
id: "bolotnaya"
hls_url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
---
Bolotnaya Square View Bolotnaya Square in real-time.