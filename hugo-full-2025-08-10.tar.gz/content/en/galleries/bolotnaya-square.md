---
slug: bolotnaya-square
title: Bolotnaya square
description: Bolotnaya square in Moscow
images:
  - src: /images/galleries/history/2023-03-31 10-29-27.JPG
  - src: /images/galleries/history/2023-03-31 10-29-27.JPG
  - src: >-
      /images/galleries/history/ENZA5rkQqmlGVulk2gX9KBzFrFUbBuTyEbXsjL8gZdtYJBPxuSAjPbP4mKLvMz80BXp_uRzDnsvgHmroF75_kNw6u6kkZB1N7KUuO669hf8S-u1e379to8T_P6H8JGmNSP2LPtQi2jCcqOjPqplKimFa6p7DXNh1UeSeQKXYkFx1kNVtA1-k4ELaK0iTd5QcI61KOKaU36VS3Tls2RDLIQ.jpeg
  - src: /images/galleries/history/Screenshot_20190626_113720.png
  - src: /images/galleries/history/Screenshot_20190626_113749.png
  - {}
---

