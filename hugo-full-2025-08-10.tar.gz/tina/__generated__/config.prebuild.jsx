// tina/config.ts
import { defineConfig } from "tinacms";
var branch = process.env.TINA_BRANCH || "main";
var galleryFields = [
  { type: "string", name: "slug", label: "Slug (\u043B\u0430\u0442\u0438\u043D\u0438\u0446\u0430, -)", required: true },
  { type: "string", name: "title", label: "\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A / Title", required: true },
  { type: "string", name: "description", label: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 / Description" },
  {
    type: "object",
    name: "images",
    label: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F / Images",
    list: true,
    fields: [
      { type: "image", name: "src", label: "\u041A\u0430\u0440\u0442\u0438\u043D\u043A\u0430", required: true },
      { type: "string", name: "caption", label: "\u041F\u043E\u0434\u043F\u0438\u0441\u044C / Caption" }
    ]
  }
];
var historyFields = [
  { type: "string", name: "slug", label: "Slug \u0437\u0430\u043F\u0438\u0441\u0438 (\u043B\u0430\u0442\u0438\u043D\u0438\u0446\u0430, -)", required: true },
  { type: "string", name: "title", label: "\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A / Title", required: true },
  { type: "string", name: "description", label: "\u041A\u0440\u0430\u0442\u043A\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 / Summary" },
  {
    type: "string",
    name: "gallery_slug",
    label: "Slug \u0433\u0430\u043B\u0435\u0440\u0435\u0438 (\u0438\u0437 Galleries)",
    required: true,
    ui: {
      description: "\u0423\u043A\u0430\u0436\u0438 slug \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u0439 \u0433\u0430\u043B\u0435\u0440\u0435\u0438 (\u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0439 \u0434\u043B\u044F RU/EN), \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: bolotnaya-square"
      // можно задать подсказки по умолчанию
      // options: ["bolotnaya-square"]
    }
  }
];
var config_default = defineConfig({
  branch,
  clientId: process.env.TINA_CLIENT_ID,
  token: process.env.TINA_TOKEN,
  build: {
    outputFolder: "public",
    publicFolder: "static"
  },
  media: {
    tina: {
      publicFolder: "static",
      mediaRoot: "images/galleries"
    }
  },
  schema: {
    collections: [
      // ===== RU posts =====
      {
        label: "\u041F\u043E\u0441\u0442\u044B (\u0420\u0443\u0441\u0441\u043A\u0438\u0439)",
        name: "ru_post",
        path: "content/ru/posts",
        format: "md",
        fields: [
          { type: "string", name: "title", label: "\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u043A", required: true },
          { type: "datetime", name: "date", label: "\u0414\u0430\u0442\u0430", required: true },
          { type: "string", name: "tags", label: "\u0422\u0435\u0433\u0438", list: true },
          { type: "rich-text", name: "body", label: "\u0422\u0435\u043A\u0441\u0442", isBody: true }
        ]
      },
      // ===== EN posts =====
      {
        label: "Posts (English)",
        name: "en_post",
        path: "content/en/posts",
        format: "md",
        fields: [
          { type: "string", name: "title", label: "Title", required: true },
          { type: "datetime", name: "date", label: "Date", required: true },
          { type: "string", name: "tags", label: "Tags", list: true },
          { type: "rich-text", name: "body", label: "Content", isBody: true }
        ]
      },
      // ===== Галереи RU =====
      {
        label: "\u0413\u0430\u043B\u0435\u0440\u0435\u0438 (RU)",
        name: "ru_gallery",
        path: "content/ru/galleries",
        format: "md",
        ui: {
          filename: { slugify: (values) => values?.slug || "" },
          defaultItem: () => ({ slug: "", title: "", description: "", images: [] })
        },
        fields: galleryFields
      },
      // ===== Galleries EN =====
      {
        label: "Galleries (EN)",
        name: "en_gallery",
        path: "content/en/galleries",
        format: "md",
        ui: {
          filename: { slugify: (values) => values?.slug || "" },
          defaultItem: () => ({ slug: "", title: "", description: "", images: [] })
        },
        fields: galleryFields
      },
      // ===== История RU =====
      {
        label: "\u0418\u0441\u0442\u043E\u0440\u0438\u044F (RU)",
        name: "ru_history",
        path: "content/ru/history",
        format: "md",
        ui: {
          filename: { slugify: (values) => values?.slug || "" },
          defaultItem: () => ({ slug: "", title: "", description: "", gallery_slug: "" })
        },
        fields: historyFields
      },
      // ===== History EN =====
      {
        label: "History (EN)",
        name: "en_history",
        path: "content/en/history",
        format: "md",
        ui: {
          filename: { slugify: (values) => values?.slug || "" },
          defaultItem: () => ({ slug: "", title: "", description: "", gallery_slug: "" })
        },
        fields: historyFields
      },
      // ===== Камеры =====
      {
        label: "\u041A\u0430\u043C\u0435\u0440\u044B",
        name: "camera",
        path: "content/cameras",
        format: "md",
        fields: [
          { type: "string", name: "name", label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", required: true },
          { type: "string", name: "stream_url", label: "\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u043F\u043E\u0442\u043E\u043A", required: true },
          { type: "image", name: "image", label: "\u041F\u0440\u0435\u0432\u044C\u044E/\u043B\u043E\u0433\u043E\u0442\u0438\u043F" },
          { type: "string", name: "description", label: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435" }
        ]
      }
    ]
  }
});
export {
  config_default as default
};
