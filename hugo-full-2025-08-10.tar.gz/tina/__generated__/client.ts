import { createClient } from "tinacms/dist/client";
import { queries } from "./types";
export const client = createClient({ url: 'http://localhost:4001/graphql', token: 'fa4b7e7d8673ca12bda85c45f7fe6955e6ec3a56', queries,  });
export default client;
  