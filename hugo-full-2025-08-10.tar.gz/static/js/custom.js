document.addEventListener('DOMContentLoaded', () => {
  AOS.init({
    duration: 600,
    once: true
  });
});
